package me.earth.phobos.features.modules.client;

import me.earth.phobos.Phobos;
import me.earth.phobos.event.events.ClientEvent;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.TextUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Managers
extends Module {
    public Setting<Boolean> betterFrames = this.register(new Setting<Boolean>("BetterMaxFPS", false));
    private static Managers INSTANCE = new Managers();
    public Setting<String> commandBracket = this.register(new Setting<String>("Bracket", "<"));
    public Setting<String> commandBracket2 = this.register(new Setting<String>("Bracket2", ">"));
    public Setting<String> command = this.register(new Setting<String>("Command", "Phobos.eu"));
    public Setting<TextUtil.Color> bracketColor = this.register(new Setting<TextUtil.Color>("BColor", TextUtil.Color.BLUE));
    public Setting<TextUtil.Color> commandColor = this.register(new Setting<TextUtil.Color>("CColor", TextUtil.Color.BLUE));
    public Setting<Integer> betterFPS = this.register(new Setting<Object>("MaxFPS", Integer.valueOf(300), Integer.valueOf(30), Integer.valueOf(1000), v -> this.betterFrames.getValue()));
    public Setting<Boolean> potions = this.register(new Setting<Boolean>("Potions", true));
    public Setting<Integer> textRadarUpdates = this.register(new Setting<Integer>("TRUpdates", 500, 0, 1000));
    public Setting<Integer> respondTime = this.register(new Setting<Integer>("SeverTime", 500, 0, 1000));
    public Setting<Integer> moduleListUpdates = this.register(new Setting<Integer>("ALUpdates", 1000, 0, 1000));
    public Setting<Float> holeRange = this.register(new Setting<Float>("HoleRange", Float.valueOf(6.0f), Float.valueOf(1.0f), Float.valueOf(32.0f)));
    public Setting<Boolean> speed = this.register(new Setting<Boolean>("Speed", true));
    public Setting<Boolean> tRadarInv = this.register(new Setting<Boolean>("TRadarInv", true));
    public Setting<Boolean> unfocusedCpu = this.register(new Setting<Boolean>("UnfocusedCPU", false));
    public Setting<Integer> cpuFPS = this.register(new Setting<Object>("UnfocusedFPS", Integer.valueOf(60), Integer.valueOf(1), Integer.valueOf(60), v -> this.unfocusedCpu.getValue()));

    public Managers() {
        super("Management", "ClientManagement", Module.Category.CLIENT, false, false, true);
        this.setInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public static Managers getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Managers();
        }
        return INSTANCE;
    }

    @Override
    public void onLoad() {
        Phobos.commandManager.setClientMessage(this.getCommandMessage());
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        if (event.getStage() == 2 && this.equals(event.getSetting().getFeature())) {
            Phobos.commandManager.setClientMessage(this.getCommandMessage());
        }
    }

    public String getCommandMessage() {
        return TextUtil.coloredString(this.commandBracket.getPlannedValue(), this.bracketColor.getPlannedValue()) + TextUtil.coloredString(this.command.getPlannedValue(), this.commandColor.getPlannedValue()) + TextUtil.coloredString(this.commandBracket2.getPlannedValue(), this.bracketColor.getPlannedValue());
    }
}
