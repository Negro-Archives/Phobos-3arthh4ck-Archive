package me.earth.phobos.features.modules.combat;

import com.google.common.util.concurrent.AtomicDouble;
import java.util.concurrent.atomic.AtomicBoolean;
import me.earth.phobos.event.events.PacketEvent;
import me.earth.phobos.features.command.Command;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.BlockUtil;
import me.earth.phobos.util.DamageUtil;
import me.earth.phobos.util.EntityUtil;
import me.earth.phobos.util.MathUtil;
import me.earth.phobos.util.Timer;
import net.minecraft.block.BlockBed;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketCombatEvent;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BedBomb
extends Module {
    private final Setting<Integer> breakDelay = this.register(new Setting<Integer>("Breakdelay", 50, 0, 500));
    private final Setting<Float> breakRange = this.register(new Setting<Float>("BreakRange", Float.valueOf(6.0f), Float.valueOf(1.0f), Float.valueOf(10.0f)));
    private final Setting<Boolean> calc = this.register(new Setting<Boolean>("Calc", false));
    private final Setting<Float> minDamage = this.register(new Setting<Object>("MinDamage", Float.valueOf(5.0f), Float.valueOf(1.0f), Float.valueOf(36.0f), v -> this.calc.getValue()));
    private final Setting<Float> range = this.register(new Setting<Object>("Range", Float.valueOf(10.0f), Float.valueOf(1.0f), Float.valueOf(12.0f), v -> this.calc.getValue()));
    private final Setting<Boolean> rotate = this.register(new Setting<Object>("Rotate", Boolean.valueOf(false), v -> this.calc.getValue()));
    private final Setting<Boolean> suicide = this.register(new Setting<Object>("Suicide", Boolean.valueOf(false), v -> this.calc.getValue()));
    private final Setting<Boolean> offhand = this.register(new Setting<Boolean>("OffHand", false));
    private final Timer breakTimer = new Timer();
    private AtomicDouble yaw = new AtomicDouble(-1.0);
    private AtomicDouble pitch = new AtomicDouble(-1.0);
    private AtomicBoolean shouldRotate = new AtomicBoolean(false);

    public BedBomb() {
        super("BedAura", "AutoPlace and Break for beds", Module.Category.COMBAT, true, false, false);
    }

    @SubscribeEvent
    public void onDeath(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketCombatEvent) {
            Entity entity;
            SPacketCombatEvent packet = (SPacketCombatEvent)event.getPacket();
            if (packet.eventType == SPacketCombatEvent.Event.ENTITY_DIED && (entity = BedBomb.mc.world.getEntityByID(packet.entityId)) instanceof EntityPlayer) {
                Command.sendMessage(entity.getName() + " died.");
            }
        }
    }

    @SubscribeEvent
    public void onDeath(PacketEvent.Send event) {
        if (this.rotate.getValue().booleanValue() && this.shouldRotate.get() && event.getPacket() instanceof CPacketPlayer) {
            CPacketPlayer packet = (CPacketPlayer)event.getPacket();
            packet.yaw = (float)this.yaw.get();
            packet.pitch = (float)this.pitch.get();
            this.shouldRotate.set(false);
        }
    }

    @Override
    public void onTick() {
        if (BedBomb.mc.player.field_71093_bK != -1 && BedBomb.mc.player.field_71093_bK != 1) {
            return;
        }
        if (this.breakTimer.passedMs(this.breakDelay.getValue().intValue())) {
            BlockPos maxPos = null;
            float maxDamage = 0.5f;
            for (BlockPos pos : BlockUtil.getBlockSphere(this.breakRange.getValue().floatValue(), BlockBed.class)) {
                if (this.calc.getValue().booleanValue()) {
                    float selfDamage = DamageUtil.calculateDamage(pos, (Entity)BedBomb.mc.player);
                    if (!((double)selfDamage + 0.5 < (double)EntityUtil.getHealth(BedBomb.mc.player)) && DamageUtil.canTakeDamage(this.suicide.getValue())) continue;
                    for (EntityPlayer player : BedBomb.mc.world.field_73010_i) {
                        float damage;
                        if (!(player.func_174818_b(pos) < MathUtil.square(this.range.getValue().floatValue())) || !EntityUtil.isValid(player, this.range.getValue().floatValue() + this.breakRange.getValue().floatValue()) || !((damage = DamageUtil.calculateDamage(pos, (Entity)player)) > selfDamage || damage > this.minDamage.getValue().floatValue() && !DamageUtil.canTakeDamage(this.suicide.getValue())) && !(damage > EntityUtil.getHealth(player)) || !(damage > maxDamage)) continue;
                        maxDamage = damage;
                        maxPos = pos;
                    }
                    continue;
                }
                maxPos = pos;
                break;
            }
            if (maxPos != null) {
                BlockUtil.rightClickBlockLegit(maxPos, this.range.getValue().floatValue(), this.rotate.getValue(), this.offhand.getValue() != false ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.yaw, this.pitch, this.shouldRotate);
                this.breakTimer.reset();
            }
        }
    }

    @Override
    public void onToggle() {
        this.yaw = new AtomicDouble(-1.0);
        this.pitch = new AtomicDouble(-1.0);
        this.shouldRotate = new AtomicBoolean(false);
    }
}
