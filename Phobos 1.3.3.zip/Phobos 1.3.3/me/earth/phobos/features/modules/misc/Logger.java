package me.earth.phobos.features.modules.misc;

import me.earth.phobos.event.events.PacketEvent;
import me.earth.phobos.features.command.Command;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.init.Items;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Logger
extends Module {
    public Setting<Packets> packets = this.register(new Setting<Packets>("Packets", Packets.OUTGOING));
    public Setting<Boolean> chat = this.register(new Setting<Boolean>("Chat", false));

    public Logger() {
        super("Logger", "Logs stuff", Module.Category.MISC, true, false, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (this.packets.getValue() == Packets.OUTGOING || this.packets.getValue() == Packets.ALL) {
            if (this.chat.getValue().booleanValue()) {
                Command.sendMessage(event.getPacket().toString());
            } else {
                System.out.println(event.getPacket().toString());
            }
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (this.packets.getValue() == Packets.INCOMING || this.packets.getValue() == Packets.ALL) {
            boolean xD = true;
            if (Logger.mc.player != null) {
                xD = Logger.mc.player.field_71069_bz.getSlot(6).getStack().getItem() == Items.ELYTRA;
                System.out.println(xD);
            }
            if (this.chat.getValue().booleanValue()) {
                Command.sendMessage(xD + event.getPacket().toString());
            } else {
                System.out.println(xD + event.getPacket().toString());
            }
        }
    }

    public static enum Packets {
        NONE,
        INCOMING,
        OUTGOING,
        ALL;

    }
}
