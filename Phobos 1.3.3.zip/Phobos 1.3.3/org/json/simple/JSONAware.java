package org.json.simple;

public interface JSONAware {
    public String toJSONString();
}
