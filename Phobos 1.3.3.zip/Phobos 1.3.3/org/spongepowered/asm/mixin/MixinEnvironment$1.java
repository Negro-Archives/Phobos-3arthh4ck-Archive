package org.spongepowered.asm.mixin;

class MixinEnvironment$1 {
}
