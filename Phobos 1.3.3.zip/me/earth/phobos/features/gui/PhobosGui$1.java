package me.earth.phobos.features.gui;

import me.earth.phobos.Phobos;
import me.earth.phobos.features.gui.components.Component;
import me.earth.phobos.features.gui.components.items.buttons.ModuleButton;
import me.earth.phobos.features.modules.Module;

class PhobosGui$1
extends Component {
    final Module.Category val$category;

    PhobosGui$1(String name, int x, int y, boolean open, Module.Category category) {
        this.val$category = category;
        super(name, x, y, open);
    }

    @Override
    public void setupItems() {
        Phobos.moduleManager.getModulesByCategory(this.val$category).forEach(module -> {
            if (!module.hidden) {
                this.addButton(new ModuleButton((Module)module));
            }
        });
    }
}
