package me.earth.phobos.features.gui.components.items.buttons;

public class StringButton$CurrentString {
    private String string;

    public StringButton$CurrentString(String string) {
        this.string = string;
    }

    public String getString() {
        return this.string;
    }
}
