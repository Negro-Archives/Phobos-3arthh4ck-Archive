package me.earth.phobos.features.modules.client;

enum Components$Direction {
    N,
    W,
    S,
    E;

}
