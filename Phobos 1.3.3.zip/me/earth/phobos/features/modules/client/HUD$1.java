package me.earth.phobos.features.modules.client;

import me.earth.phobos.features.modules.client.HUD;

class HUD$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$client$HUD$WaterMark;
    static final int[] $SwitchMap$me$earth$phobos$features$modules$client$HUD$Greeter;

    static {
        $SwitchMap$me$earth$phobos$features$modules$client$HUD$Greeter = new int[HUD.Greeter.values().length];
        try {
            HUD$1.$SwitchMap$me$earth$phobos$features$modules$client$HUD$Greeter[HUD.Greeter.TIME.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HUD$1.$SwitchMap$me$earth$phobos$features$modules$client$HUD$Greeter[HUD.Greeter.LONG.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HUD$1.$SwitchMap$me$earth$phobos$features$modules$client$HUD$Greeter[HUD.Greeter.CUSTOM.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        $SwitchMap$me$earth$phobos$features$modules$client$HUD$WaterMark = new int[HUD.WaterMark.values().length];
        try {
            HUD$1.$SwitchMap$me$earth$phobos$features$modules$client$HUD$WaterMark[HUD.WaterMark.PHOBOS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HUD$1.$SwitchMap$me$earth$phobos$features$modules$client$HUD$WaterMark[HUD.WaterMark.EARTH.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
