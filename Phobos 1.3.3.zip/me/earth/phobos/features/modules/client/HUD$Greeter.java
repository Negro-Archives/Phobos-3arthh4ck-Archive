package me.earth.phobos.features.modules.client;

public enum HUD$Greeter {
    NONE,
    NAME,
    TIME,
    LONG,
    CUSTOM;

}
