package me.earth.phobos.features.modules.client;

public enum HUD$LagNotify {
    NONE,
    RED,
    GRAY;

}
