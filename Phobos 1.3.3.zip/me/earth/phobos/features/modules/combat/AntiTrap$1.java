package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.AntiTrap;

class AntiTrap$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$AntiTrap$Rotate;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$AntiTrap$Rotate = new int[AntiTrap.Rotate.values().length];
        try {
            AntiTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AntiTrap$Rotate[AntiTrap.Rotate.NONE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            AntiTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AntiTrap$Rotate[AntiTrap.Rotate.NORMAL.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            AntiTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AntiTrap$Rotate[AntiTrap.Rotate.PACKET.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
