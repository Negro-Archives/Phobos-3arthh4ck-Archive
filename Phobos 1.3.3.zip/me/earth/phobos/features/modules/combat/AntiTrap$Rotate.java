package me.earth.phobos.features.modules.combat;

public enum AntiTrap$Rotate {
    NONE,
    NORMAL,
    PACKET;

}
