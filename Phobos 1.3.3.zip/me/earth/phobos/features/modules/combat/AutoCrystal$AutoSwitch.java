package me.earth.phobos.features.modules.combat;

public enum AutoCrystal$AutoSwitch {
    NONE,
    TOGGLE,
    ALWAYS;

}
