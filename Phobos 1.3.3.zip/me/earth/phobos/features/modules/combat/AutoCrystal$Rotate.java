package me.earth.phobos.features.modules.combat;

public enum AutoCrystal$Rotate {
    OFF,
    PLACE,
    BREAK,
    ALL;

}
