package me.earth.phobos.features.modules.combat;

public enum AutoCrystal$Settings {
    PLACE,
    BREAK,
    RENDER,
    MISC;

}
