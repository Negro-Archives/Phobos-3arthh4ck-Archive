package me.earth.phobos.features.modules.combat;

public enum Killaura$TargetMode {
    FOCUS,
    CLOSEST,
    HEALTH,
    SMART;

}
