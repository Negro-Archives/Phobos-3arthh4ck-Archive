package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.Surround;

class Surround$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode = new int[Surround.MovementMode.values().length];
        try {
            Surround$1.$SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode[Surround.MovementMode.NONE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Surround$1.$SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode[Surround.MovementMode.STATIC.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Surround$1.$SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode[Surround.MovementMode.LIMIT.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Surround$1.$SwitchMap$me$earth$phobos$features$modules$combat$Surround$MovementMode[Surround.MovementMode.OFF.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
