package me.earth.phobos.features.modules.misc;

import me.earth.phobos.features.modules.misc.Announcer;

public class Announcer$Message {
    public final Announcer.Action action;
    public final String name;
    public final int amount;

    public Announcer$Message(Announcer.Action action, String name, int amount) {
        this.action = action;
        this.name = name;
        this.amount = amount;
    }
}
