package me.earth.phobos.features.modules.misc;

import me.earth.phobos.features.modules.misc.Nuker;

class Nuker$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$misc$Nuker$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$misc$Nuker$Mode = new int[Nuker.Mode.values().length];
        try {
            Nuker$1.$SwitchMap$me$earth$phobos$features$modules$misc$Nuker$Mode[Nuker.Mode.SELECTION.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Nuker$1.$SwitchMap$me$earth$phobos$features$modules$misc$Nuker$Mode[Nuker.Mode.NUKE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Nuker$1.$SwitchMap$me$earth$phobos$features$modules$misc$Nuker$Mode[Nuker.Mode.ALL.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
