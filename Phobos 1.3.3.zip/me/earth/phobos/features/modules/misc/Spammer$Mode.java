package me.earth.phobos.features.modules.misc;

public enum Spammer$Mode {
    FILE,
    PWORD;

}
