package me.earth.phobos.features.modules.misc;

public enum Spammer$PwordMode {
    MSG,
    EVERYONE,
    CHAT;

}
