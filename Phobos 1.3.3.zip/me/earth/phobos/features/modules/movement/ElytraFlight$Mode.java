package me.earth.phobos.features.modules.movement;

public enum ElytraFlight$Mode {
    VANILLA,
    PACKET,
    BOOST,
    FLY,
    BYPASS,
    BETTER,
    OHARE,
    TOOBEE;

}
