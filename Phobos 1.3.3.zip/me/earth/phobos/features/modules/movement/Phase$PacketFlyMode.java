package me.earth.phobos.features.modules.movement;

public enum Phase$PacketFlyMode {
    NONE,
    SETBACK;

}
