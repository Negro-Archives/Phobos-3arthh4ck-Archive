package me.earth.phobos.features.modules.movement;

import me.earth.phobos.features.modules.movement.Speed;

class Speed$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$movement$Speed$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$movement$Speed$Mode = new int[Speed.Mode.values().length];
        try {
            Speed$1.$SwitchMap$me$earth$phobos$features$modules$movement$Speed$Mode[Speed.Mode.BOOST.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Speed$1.$SwitchMap$me$earth$phobos$features$modules$movement$Speed$Mode[Speed.Mode.ACCEL.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Speed$1.$SwitchMap$me$earth$phobos$features$modules$movement$Speed$Mode[Speed.Mode.ONGROUND.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
