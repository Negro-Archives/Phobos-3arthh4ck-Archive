package me.earth.phobos.features.modules.movement;

import me.earth.phobos.features.modules.movement.Static;

class Static$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$movement$Static$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$movement$Static$Mode = new int[Static.Mode.values().length];
        try {
            Static$1.$SwitchMap$me$earth$phobos$features$modules$movement$Static$Mode[Static.Mode.STATIC.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Static$1.$SwitchMap$me$earth$phobos$features$modules$movement$Static$Mode[Static.Mode.ROOF.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Static$1.$SwitchMap$me$earth$phobos$features$modules$movement$Static$Mode[Static.Mode.NOVOID.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
