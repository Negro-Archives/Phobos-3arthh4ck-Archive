package me.earth.phobos.features.modules.movement;

public enum Static$Mode {
    STATIC,
    ROOF,
    NOVOID;

}
