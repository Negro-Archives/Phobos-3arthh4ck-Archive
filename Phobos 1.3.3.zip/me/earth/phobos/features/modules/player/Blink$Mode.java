package me.earth.phobos.features.modules.player;

public enum Blink$Mode {
    MANUAL,
    TIME,
    DISTANCE,
    PACKETS;

}
