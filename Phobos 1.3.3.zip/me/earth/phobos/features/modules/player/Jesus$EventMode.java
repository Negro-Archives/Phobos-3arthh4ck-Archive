package me.earth.phobos.features.modules.player;

public enum Jesus$EventMode {
    PRE,
    POST,
    ALL;

}
