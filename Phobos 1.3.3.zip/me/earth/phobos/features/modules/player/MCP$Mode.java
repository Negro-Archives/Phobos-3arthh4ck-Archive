package me.earth.phobos.features.modules.player;

public enum MCP$Mode {
    TOGGLE,
    MIDDLECLICK;

}
