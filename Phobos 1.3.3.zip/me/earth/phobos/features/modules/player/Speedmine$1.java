package me.earth.phobos.features.modules.player;

import me.earth.phobos.features.modules.player.Speedmine;

class Speedmine$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$player$Speedmine$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$player$Speedmine$Mode = new int[Speedmine.Mode.values().length];
        try {
            Speedmine$1.$SwitchMap$me$earth$phobos$features$modules$player$Speedmine$Mode[Speedmine.Mode.PACKET.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Speedmine$1.$SwitchMap$me$earth$phobos$features$modules$player$Speedmine$Mode[Speedmine.Mode.DAMAGE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Speedmine$1.$SwitchMap$me$earth$phobos$features$modules$player$Speedmine$Mode[Speedmine.Mode.INSTANT.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
