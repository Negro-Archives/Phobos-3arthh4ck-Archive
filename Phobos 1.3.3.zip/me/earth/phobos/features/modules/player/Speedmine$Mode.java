package me.earth.phobos.features.modules.player;

public enum Speedmine$Mode {
    PACKET,
    DAMAGE,
    INSTANT;

}
