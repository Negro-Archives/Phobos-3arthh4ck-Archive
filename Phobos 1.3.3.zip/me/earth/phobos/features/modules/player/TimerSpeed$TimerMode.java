package me.earth.phobos.features.modules.player;

public enum TimerSpeed$TimerMode {
    NORMAL,
    SWITCH;

}
