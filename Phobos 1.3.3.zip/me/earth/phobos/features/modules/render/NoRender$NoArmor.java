package me.earth.phobos.features.modules.render;

public enum NoRender$NoArmor {
    NONE,
    ALL,
    HELMET;

}
