package me.earth.phobos.util;

public enum InventoryUtil$Switch {
    NORMAL,
    SILENT,
    NONE;

}
