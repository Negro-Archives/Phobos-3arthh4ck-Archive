package org.spongepowered.asm.mixin;

enum MixinEnvironment$Option$Inherit {
    INHERIT,
    ALLOW_OVERRIDE,
    INDEPENDENT,
    ALWAYS_FALSE;

}
