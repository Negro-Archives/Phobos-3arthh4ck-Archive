package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment;

final class MixinEnvironment$Side$1
extends MixinEnvironment.Side {
    @Override
    protected boolean detect() {
        return false;
    }
}
