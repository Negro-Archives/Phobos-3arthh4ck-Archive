package org.spongepowered.asm.mixin.injection.points;

public enum BeforeInvoke$SearchType {
    STRICT,
    PERMISSIVE;

}
