package org.spongepowered.asm.mixin.transformer;

enum ClassInfo$Member$Type {
    METHOD,
    FIELD;

}
