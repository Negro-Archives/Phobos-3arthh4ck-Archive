package org.spongepowered.asm.mixin.transformer.ext;

public interface IHotSwap {
    public void registerMixinClass(String var1);

    public void registerTargetClass(String var1, byte[] var2);
}
