package org.spongepowered.asm.obfuscation.mapping;

public enum IMapping$Type {
    FIELD,
    METHOD,
    CLASS,
    PACKAGE;

}
