package org.spongepowered.asm.util;

public enum PrettyPrinter$Alignment {
    LEFT,
    RIGHT;

}
