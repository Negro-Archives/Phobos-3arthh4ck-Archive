package org.spongepowered.asm.util;

interface PrettyPrinter$IVariableWidthEntry {
    public int getWidth();
}
