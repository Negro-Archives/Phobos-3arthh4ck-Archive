package org.spongepowered.asm.util.throwables;

import org.spongepowered.asm.util.throwables.SyntheticBridgeException;

class SyntheticBridgeException$1 {
    static final int[] $SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem;

    static {
        $SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem = new int[SyntheticBridgeException.Problem.values().length];
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_INSN.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_LOAD.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_CAST.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_INVOKE_NAME.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_INVOKE_DESC.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException.Problem.BAD_LENGTH.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
