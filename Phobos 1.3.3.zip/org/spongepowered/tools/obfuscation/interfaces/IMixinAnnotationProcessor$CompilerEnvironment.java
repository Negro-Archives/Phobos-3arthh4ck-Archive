package org.spongepowered.tools.obfuscation.interfaces;

public enum IMixinAnnotationProcessor$CompilerEnvironment {
    JAVAC,
    JDT;

}
