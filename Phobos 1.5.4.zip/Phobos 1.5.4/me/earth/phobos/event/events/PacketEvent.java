package me.earth.phobos.event.events;

import me.earth.phobos.event.EventStage;
import net.minecraft.network.Packet;

public class PacketEvent
extends EventStage {
    private final Packet<?> packet;

    public PacketEvent(int stage, Packet<?> packet) {
        super(stage);
        this.packet = packet;
    }

    public <T extends Packet<?>> T getPacket() {
        return (T)this.packet;
    }
}
