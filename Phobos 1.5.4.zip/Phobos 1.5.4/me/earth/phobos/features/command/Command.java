package me.earth.phobos.features.command;

import me.earth.phobos.Phobos;
import me.earth.phobos.features.Feature;
import me.earth.phobos.features.command.Command;
import net.minecraft.util.text.ITextComponent;

public abstract class Command
extends Feature {
    protected String name;
    protected String[] commands;

    public Command(String name) {
        super(name);
        this.name = name;
        this.commands = new String[]{""};
    }

    public Command(String name, String[] commands) {
        super(name);
        this.name = name;
        this.commands = commands;
    }

    public abstract void execute(String[] var1);

    public static void sendMessage(String message, boolean notification) {
        Command.sendSilentMessage(Phobos.commandManager.getClientMessage() + " " + "\u00a7r" + message);
        if (notification) {
            Phobos.notificationManager.addNotification(message, 3000L);
        }
    }

    public static void sendMessage(String message) {
        Command.sendSilentMessage(Phobos.commandManager.getClientMessage() + " " + "\u00a7r" + message);
    }

    public static void sendSilentMessage(String message) {
        if (Command.nullCheck()) {
            return;
        }
        Command.mc.player.sendMessage((ITextComponent)new ChatMessage(message));
    }

    @Override
    public String getName() {
        return this.name;
    }

    public String[] getCommands() {
        return this.commands;
    }

    public static String getCommandPrefix() {
        return Phobos.commandManager.getPrefix();
    }
}
