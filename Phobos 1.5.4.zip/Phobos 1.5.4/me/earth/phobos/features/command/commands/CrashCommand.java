package me.earth.phobos.features.command.commands;

import me.earth.phobos.features.command.Command;

public class CrashCommand
extends Command {
    int packets;

    public CrashCommand() {
        super("crash", new String[]{"crash"});
    }

    @Override
    public void execute(String[] commands) {
        new /* Unavailable Anonymous Inner Class!! */.start();
    }
}
