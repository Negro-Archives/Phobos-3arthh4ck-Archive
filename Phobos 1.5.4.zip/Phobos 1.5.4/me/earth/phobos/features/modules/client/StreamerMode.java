package me.earth.phobos.features.modules.client;

import java.awt.EventQueue;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import me.earth.phobos.Phobos;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.modules.client.StreamerMode;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.EntityUtil;
import me.earth.phobos.util.TextUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.PotionEffect;

public class StreamerMode
extends Module {
    private SecondScreenFrame window = null;
    public Setting<Integer> width = this.register(new Setting<Integer>("Width", 600, 100, 3160));
    public Setting<Integer> height = this.register(new Setting<Integer>("Height", 900, 100, 2140));

    public StreamerMode() {
        super("StreamerMode", "Displays client info in a second window.", Module.Category.CLIENT, false, false, false);
    }

    @Override
    public void onEnable() {
        EventQueue.invokeLater(() -> {
            if (this.window == null) {
                this.window = new SecondScreenFrame(this);
            }
            this.window.setVisible(true);
        });
    }

    @Override
    public void onDisable() {
        if (this.window != null) {
            this.window.setVisible(false);
        }
        this.window = null;
    }

    @Override
    public void onLogout() {
        if (this.window != null) {
            ArrayList<String> drawInfo = new ArrayList<String>();
            drawInfo.add("Phobos v1.5.4");
            drawInfo.add("");
            drawInfo.add("No Connection.");
            this.window.setToDraw(drawInfo);
        }
    }

    @Override
    public void onUnload() {
        this.disable();
    }

    @Override
    public void onLoad() {
        this.disable();
    }

    @Override
    public void onUpdate() {
        if (this.window != null) {
            ArrayList<String> drawInfo = new ArrayList<String>();
            drawInfo.add("Phobos v1.5.4");
            drawInfo.add("");
            drawInfo.add("Fps: " + Minecraft.debugFPS);
            drawInfo.add("TPS: " + Phobos.serverManager.getTPS());
            drawInfo.add("Ping: " + Phobos.serverManager.getPing() + "ms");
            drawInfo.add("Speed: " + Phobos.speedManager.getSpeedKpH() + "km/h");
            drawInfo.add("Time: " + new SimpleDateFormat("h:mm a").format(new Date()));
            boolean inHell = StreamerMode.mc.world.func_180494_b(StreamerMode.mc.player.getPosition()).getBiomeName().equals("Hell");
            int posX = (int)StreamerMode.mc.player.field_70165_t;
            int posY = (int)StreamerMode.mc.player.field_70163_u;
            int posZ = (int)StreamerMode.mc.player.field_70161_v;
            float nether = !inHell ? 0.125f : 8.0f;
            int hposX = (int)(StreamerMode.mc.player.field_70165_t * (double)nether);
            int hposZ = (int)(StreamerMode.mc.player.field_70161_v * (double)nether);
            String coordinates = "XYZ " + posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]";
            String text = Phobos.rotationManager.getDirection4D(false);
            drawInfo.add("");
            drawInfo.add(text);
            drawInfo.add(coordinates);
            drawInfo.add("");
            for (Module module : Phobos.moduleManager.sortedModules) {
                String moduleName = TextUtil.stripColor(module.getFullArrayString());
                drawInfo.add(moduleName);
            }
            drawInfo.add("");
            for (PotionEffect effect : Phobos.potionManager.getOwnPotions()) {
                String potionText = TextUtil.stripColor(Phobos.potionManager.getColoredPotionString(effect));
                drawInfo.add(potionText);
            }
            drawInfo.add("");
            Map<String, Integer> map = EntityUtil.getTextRadarPlayers();
            if (!map.isEmpty()) {
                for (Map.Entry<String, Integer> player : map.entrySet()) {
                    String playerText = TextUtil.stripColor(player.getKey());
                    drawInfo.add(playerText);
                }
            }
            this.window.setToDraw(drawInfo);
        }
    }
}
