package me.earth.phobos.features.modules.player;

import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.client.settings.KeyBinding;

public class AntiDelay
extends Module {
    public Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.SWORDCRYSTAL));
    public Setting<Integer> swordSlotSet = this.register(new Setting<Integer>("SwordSlot", 5, 1, 9));
    public Setting<Integer> crystaSlotSet = this.register(new Setting<Integer>("CrystalSlot", 1, 1, 9));
    private static AntiDelay instance;
    private boolean didSwitch = false;

    public AntiDelay() {
        super("AntiDelay", "Removes Hotbar Delay", Module.Category.PLAYER, false, false, false);
        instance = this;
    }

    public static AntiDelay getInstance() {
        if (instance == null) {
            instance = new AntiDelay();
        }
        return instance;
    }

    @Override
    public void onUpdate() {
        if (AntiDelay.fullNullCheck()) {
            return;
        }
    }

    public boolean processPressed(KeyBinding binding) {
        int number = 0;
        try {
            number = Integer.parseInt(binding.getDisplayName());
        }
        catch (Exception exception) {
            // empty catch block
        }
        return binding.isPressed();
    }

    private void doSwitch(int slot1, int slot2) {
    }

    private int getSwordSlot() {
        return this.swordSlotSet.getValue() - 1;
    }

    private int getCrystalSlot() {
        return this.crystaSlotSet.getValue() - 1;
    }

    public static enum Mode {
        SWORDCRYSTAL;

    }
}
