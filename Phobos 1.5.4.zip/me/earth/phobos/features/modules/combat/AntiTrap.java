package me.earth.phobos.features.modules.combat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import me.earth.phobos.Phobos;
import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.BlockUtil;
import me.earth.phobos.util.EntityUtil;
import me.earth.phobos.util.InventoryUtil;
import me.earth.phobos.util.MathUtil;
import me.earth.phobos.util.Timer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiTrap
extends Module {
    public Setting<Rotate> rotate = this.register(new Setting<Rotate>("Rotate", Rotate.NORMAL));
    private final Setting<Integer> coolDown = this.register(new Setting<Integer>("CoolDown", 400, 0, 1000));
    private final Setting<InventoryUtil.Switch> switchMode = this.register(new Setting<InventoryUtil.Switch>("Switch", InventoryUtil.Switch.NORMAL));
    public Setting<Boolean> sortY = this.register(new Setting<Boolean>("SortY", true));
    public static Set<BlockPos> placedPos = new HashSet<BlockPos>();
    private final Vec3d[] surroundTargets = new Vec3d[]{new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, -1.0), new Vec3d(-1.0, 0.0, 1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, -1.0), new Vec3d(-1.0, 1.0, 1.0)};
    private int lastHotbarSlot = -1;
    private boolean switchedItem;
    private boolean offhand = false;
    private final Timer timer = new Timer();

    public AntiTrap() {
        super("AntiTrap", "Places a crystal to prevent you getting trapped.", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onEnable() {
        if (AntiTrap.fullNullCheck() || !this.timer.passedMs(this.coolDown.getValue().intValue())) {
            this.disable();
            return;
        }
        this.lastHotbarSlot = AntiTrap.mc.player.field_71071_by.currentItem;
    }

    @Override
    public void onDisable() {
        if (AntiTrap.fullNullCheck()) {
            return;
        }
        this.switchItem(true);
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
        if (!AntiTrap.fullNullCheck() && event.getStage() == 0) {
            this.doAntiTrap();
        }
    }

    public void doAntiTrap() {
        boolean bl = this.offhand = AntiTrap.mc.player.func_184592_cb().getItem() == Items.END_CRYSTAL;
        if (!this.offhand && InventoryUtil.findHotbarBlock(ItemEndCrystal.class) == -1) {
            this.disable();
            return;
        }
        this.lastHotbarSlot = AntiTrap.mc.player.field_71071_by.currentItem;
        ArrayList<Vec3d> targets = new ArrayList<Vec3d>();
        Collections.addAll(targets, BlockUtil.convertVec3ds(AntiTrap.mc.player.func_174791_d(), this.surroundTargets));
        EntityPlayer closestPlayer = EntityUtil.getClosestEnemy(6.0);
        if (closestPlayer != null) {
            targets.sort((vec3d, vec3d2) -> Double.compare(closestPlayer.func_70092_e(vec3d2.x, vec3d2.y, vec3d2.z), closestPlayer.func_70092_e(vec3d.x, vec3d.y, vec3d.z)));
            if (this.sortY.getValue().booleanValue()) {
                targets.sort(Comparator.comparingDouble(vec3d -> vec3d.y));
            }
        }
        for (Vec3d vec3d3 : targets) {
            BlockPos pos = new BlockPos(vec3d3);
            if (!BlockUtil.canPlaceCrystal(pos)) continue;
            this.placeCrystal(pos);
            this.disable();
            break;
        }
    }

    private void placeCrystal(BlockPos pos) {
        boolean mainhand;
        boolean bl = mainhand = AntiTrap.mc.player.func_184614_ca().getItem() == Items.END_CRYSTAL;
        if (!(mainhand || this.offhand || this.switchItem(false))) {
            this.disable();
            return;
        }
        RayTraceResult result = AntiTrap.mc.world.func_72933_a(new Vec3d(AntiTrap.mc.player.field_70165_t, AntiTrap.mc.player.field_70163_u + (double)AntiTrap.mc.player.func_70047_e(), AntiTrap.mc.player.field_70161_v), new Vec3d((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() - 0.5, (double)pos.func_177952_p() + 0.5));
        EnumFacing facing = result == null || result.sideHit == null ? EnumFacing.UP : result.sideHit;
        float[] angle = MathUtil.calcAngle(AntiTrap.mc.player.func_174824_e(mc.getRenderPartialTicks()), new Vec3d((float)pos.func_177958_n() + 0.5f, (float)pos.func_177956_o() - 0.5f, (float)pos.func_177952_p() + 0.5f));
        switch (this.rotate.getValue()) {
            case NONE: {
                break;
            }
            case NORMAL: {
                Phobos.rotationManager.setPlayerRotations(angle[0], angle[1]);
                break;
            }
            case PACKET: {
                AntiTrap.mc.player.connection.sendPacket(new CPacketPlayer.Rotation(angle[0], MathHelper.normalizeAngle((int)((int)angle[1]), (int)360), AntiTrap.mc.player.field_70122_E));
                break;
            }
        }
        placedPos.add(pos);
        AntiTrap.mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos, facing, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
        AntiTrap.mc.player.swingArm(EnumHand.MAIN_HAND);
        this.timer.reset();
    }

    private boolean switchItem(boolean back) {
        if (this.offhand) {
            return true;
        }
        boolean[] value = InventoryUtil.switchItemToItem(back, this.lastHotbarSlot, this.switchedItem, this.switchMode.getValue(), Items.END_CRYSTAL);
        this.switchedItem = value[0];
        return value[1];
    }

    public static enum Rotate {
        NONE,
        NORMAL,
        PACKET;

    }
}
