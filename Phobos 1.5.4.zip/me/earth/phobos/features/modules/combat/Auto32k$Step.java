package me.earth.phobos.features.modules.combat;

public enum Auto32k$Step {
    PRE,
    HOPPER,
    SHULKER,
    CLICKHOPPER,
    HOPPERGUI,
    DISPENSER_HELPING,
    DISPENSER_GUI,
    DISPENSER,
    CLICK_DISPENSER,
    REDSTONE;

}
