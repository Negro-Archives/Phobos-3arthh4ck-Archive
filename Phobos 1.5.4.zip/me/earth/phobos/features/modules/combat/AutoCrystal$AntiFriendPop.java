package me.earth.phobos.features.modules.combat;

public enum AutoCrystal$AntiFriendPop {
    NONE,
    PLACE,
    BREAK,
    ALL;

}
