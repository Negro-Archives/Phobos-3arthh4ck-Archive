package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.AutoCrystal;

class AutoCrystal$RAutoCrystal
implements Runnable {
    private static AutoCrystal$RAutoCrystal instance;
    private AutoCrystal autoCrystal;

    private AutoCrystal$RAutoCrystal() {
    }

    public static AutoCrystal$RAutoCrystal getInstance(AutoCrystal autoCrystal) {
        if (instance == null) {
            instance = new AutoCrystal$RAutoCrystal();
        }
        AutoCrystal$RAutoCrystal.instance.autoCrystal = autoCrystal;
        return instance;
    }

    @Override
    public void run() {
        if (this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.POOL) {
            if (this.autoCrystal.isOn()) {
                this.autoCrystal.doAutoCrystal();
            }
        } else if (this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
            while (this.autoCrystal.isOn() && this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
                if (this.autoCrystal.shouldInterrupt.get()) {
                    this.autoCrystal.shouldInterrupt.set(false);
                    this.autoCrystal.syncroTimer.reset();
                    this.autoCrystal.thread.interrupt();
                    break;
                }
                this.autoCrystal.doAutoCrystal();
                try {
                    Thread.sleep(this.autoCrystal.threadDelay.getValue().intValue());
                }
                catch (InterruptedException e) {
                    this.autoCrystal.thread.interrupt();
                    e.printStackTrace();
                }
            }
        }
    }
}
