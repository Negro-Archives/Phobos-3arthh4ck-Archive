package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.AutoTrap;

class AutoTrap$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$AutoTrap$Pattern;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$AutoTrap$Pattern = new int[AutoTrap.Pattern.values().length];
        try {
            AutoTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AutoTrap$Pattern[AutoTrap.Pattern.STATIC.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            AutoTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AutoTrap$Pattern[AutoTrap.Pattern.SMART.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            AutoTrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$AutoTrap$Pattern[AutoTrap.Pattern.OPEN.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
