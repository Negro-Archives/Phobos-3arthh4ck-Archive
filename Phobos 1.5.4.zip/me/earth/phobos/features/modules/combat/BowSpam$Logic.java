package me.earth.phobos.features.modules.combat;

public enum BowSpam$Logic {
    BREAKPLACE,
    PLACEBREAK;

}
