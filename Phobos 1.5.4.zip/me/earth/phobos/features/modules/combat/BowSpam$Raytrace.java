package me.earth.phobos.features.modules.combat;

public enum BowSpam$Raytrace {
    NONE,
    PLACE,
    BREAK,
    FULL;

}
