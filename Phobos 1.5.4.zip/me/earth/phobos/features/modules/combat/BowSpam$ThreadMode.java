package me.earth.phobos.features.modules.combat;

public enum BowSpam$ThreadMode {
    POOL,
    WHILE;

}
