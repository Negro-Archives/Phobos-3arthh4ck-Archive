package me.earth.phobos.features.modules.combat;

public enum Crasher$Mode {
    ONCE,
    SPAM;

}
