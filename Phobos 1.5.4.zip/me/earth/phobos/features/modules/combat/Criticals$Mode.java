package me.earth.phobos.features.modules.combat;

public enum Criticals$Mode {
    JUMP,
    MINIJUMP,
    PACKET,
    BYPASS;

}
