package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.HoleFiller;

class HoleFiller$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$HoleFiller$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$HoleFiller$Mode = new int[HoleFiller.Mode.values().length];
        try {
            HoleFiller$1.$SwitchMap$me$earth$phobos$features$modules$combat$HoleFiller$Mode[HoleFiller.Mode.WEBS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            HoleFiller$1.$SwitchMap$me$earth$phobos$features$modules$combat$HoleFiller$Mode[HoleFiller.Mode.OBSIDIAN.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
