package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.Offhand;

class Offhand$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2;
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$NameMode;
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode = new int[Offhand.Mode.values().length];
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode[Offhand.Mode.GAPPLES.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode[Offhand.Mode.WEBS.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode[Offhand.Mode.OBSIDIAN.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode[Offhand.Mode.CRYSTALS.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$NameMode = new int[Offhand.NameMode.values().length];
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$NameMode[Offhand.NameMode.MODE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$NameMode[Offhand.NameMode.TOTEM.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        $SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2 = new int[Offhand.Mode2.values().length];
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2[Offhand.Mode2.TOTEMS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2[Offhand.Mode2.GAPPLES.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2[Offhand.Mode2.WEBS.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Offhand$1.$SwitchMap$me$earth$phobos$features$modules$combat$Offhand$Mode2[Offhand.Mode2.OBSIDIAN.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
