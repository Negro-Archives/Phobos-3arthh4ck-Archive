package me.earth.phobos.features.modules.combat;

public enum Offhand$Type {
    OLD,
    NEW;

}
