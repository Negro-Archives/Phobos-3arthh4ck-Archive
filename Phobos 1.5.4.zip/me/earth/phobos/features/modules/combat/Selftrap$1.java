package me.earth.phobos.features.modules.combat;

import me.earth.phobos.features.modules.combat.Selftrap;

class Selftrap$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$combat$Selftrap$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$combat$Selftrap$Mode = new int[Selftrap.Mode.values().length];
        try {
            Selftrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$Selftrap$Mode[Selftrap.Mode.WEBS.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Selftrap$1.$SwitchMap$me$earth$phobos$features$modules$combat$Selftrap$Mode[Selftrap.Mode.OBSIDIAN.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
