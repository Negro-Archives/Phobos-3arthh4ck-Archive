package me.earth.phobos.features.modules.misc;

public enum AntiPackets$Mode {
    CLIENT,
    SERVER;

}
