package me.earth.phobos.features.modules.misc;

public enum ChatModifier$Suffix {
    NONE,
    PHOBOS,
    EARTH;

}
