package me.earth.phobos.features.modules.misc;

public enum Nuker$Mode {
    SELECTION,
    ALL,
    NUKE;

}
