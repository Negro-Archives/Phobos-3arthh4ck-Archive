package me.earth.phobos.features.modules.misc;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import me.earth.phobos.features.modules.misc.Translator;
import me.earth.phobos.util.Util;
import net.minecraft.network.play.client.CPacketChatMessage;

public class Translator$Translate
extends Thread {
    Thread thread;
    public String message;
    public Translator.Language sourceLang;
    public Translator.Language lang;
    public String finalMessage = null;

    public Translator$Translate(String message, Translator.Language sourceLang, Translator.Language lang) {
        super("Translate");
        this.message = message;
        this.sourceLang = sourceLang;
        this.lang = lang;
    }

    @Override
    public void run() {
        try {
            this.finalMessage = this.request("https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20200403T133250Z.c0062863622d7503.ca7fca44b9d2259ba3dadd61ddf7c15a2c9f3876&text=" + this.message.replace(" ", "%20") + "&lang=" + this.sourceLang.getCode() + "-" + this.lang.getCode()).get("text").getAsString();
            Util.mc.player.connection.sendPacket(new CPacketChatMessage(this.finalMessage));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void start() {
        if (this.thread == null) {
            this.thread = new Thread((Runnable)this, "Translate");
            this.thread.start();
        }
    }

    private JsonObject request(String URL2) throws IOException {
        URL url = new URL(URL2);
        URLConnection urlConn = url.openConnection();
        urlConn.addRequestProperty("User-Agent", "Mozilla");
        InputStream inStream = urlConn.getInputStream();
        JsonParser jp = new JsonParser();
        JsonElement root = jp.parse(new InputStreamReader((InputStream)urlConn.getContent()));
        inStream.close();
        return root.getAsJsonObject();
    }
}
