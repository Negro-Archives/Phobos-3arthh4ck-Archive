package me.earth.phobos.features.modules.movement;

import me.earth.phobos.features.modules.movement.ElytraFlight;

class ElytraFlight$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode = new int[ElytraFlight.Mode.values().length];
        try {
            ElytraFlight$1.$SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode[ElytraFlight.Mode.BOOST.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ElytraFlight$1.$SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode[ElytraFlight.Mode.FLY.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ElytraFlight$1.$SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode[ElytraFlight.Mode.VANILLA.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ElytraFlight$1.$SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode[ElytraFlight.Mode.PACKET.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ElytraFlight$1.$SwitchMap$me$earth$phobos$features$modules$movement$ElytraFlight$Mode[ElytraFlight.Mode.BYPASS.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
