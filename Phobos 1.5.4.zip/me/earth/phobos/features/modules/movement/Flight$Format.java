package me.earth.phobos.features.modules.movement;

public enum Flight$Format {
    DAMAGE,
    SLOW,
    DELAY,
    NORMAL,
    PACKET;

}
