package me.earth.phobos.features.modules.movement;

enum Flight$PacketMode {
    Up,
    Down,
    Zero,
    Y,
    X,
    Z,
    XZ;

}
