package me.earth.phobos.features.modules.movement;

public enum NoFall$Mode {
    PACKET,
    BUCKET,
    ELYTRA;

}
