package me.earth.phobos.features.modules.movement;

import me.earth.phobos.features.modules.movement.Sprint;

class Sprint$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$movement$Sprint$Mode;

    static {
        $SwitchMap$me$earth$phobos$features$modules$movement$Sprint$Mode = new int[Sprint.Mode.values().length];
        try {
            Sprint$1.$SwitchMap$me$earth$phobos$features$modules$movement$Sprint$Mode[Sprint.Mode.RAGE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Sprint$1.$SwitchMap$me$earth$phobos$features$modules$movement$Sprint$Mode[Sprint.Mode.LEGIT.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
