package me.earth.phobos.features.modules.movement;

import me.earth.phobos.Phobos;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.modules.movement.Flight;
import me.earth.phobos.features.modules.movement.Phase;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class Static
extends Module {
    private final Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.ROOF));
    private final Setting<Boolean> disabler = this.register(new Setting<Object>("Disable", Boolean.valueOf(true), v -> this.mode.getValue() == Mode.ROOF));
    private final Setting<Boolean> ySpeed = this.register(new Setting<Object>("YSpeed", Boolean.valueOf(false), v -> this.mode.getValue() == Mode.STATIC));
    private final Setting<Float> speed = this.register(new Setting<Object>("Speed", Float.valueOf(0.1f), Float.valueOf(0.0f), Float.valueOf(10.0f), v -> this.ySpeed.getValue() != false && this.mode.getValue() == Mode.STATIC));
    private final Setting<Float> height = this.register(new Setting<Object>("Height", Float.valueOf(3.0f), Float.valueOf(0.0f), Float.valueOf(256.0f), v -> this.mode.getValue() == Mode.NOVOID));

    public Static() {
        super("Static", "Stops any movement. Glitches you up.", Module.Category.MOVEMENT, false, false, false);
    }

    @Override
    public void onUpdate() {
        if (Static.fullNullCheck()) {
            return;
        }
        switch (this.mode.getValue()) {
            case STATIC: {
                Static.mc.player.field_71075_bZ.isFlying = false;
                Static.mc.player.field_70159_w = 0.0;
                Static.mc.player.field_70181_x = 0.0;
                Static.mc.player.field_70179_y = 0.0;
                if (!this.ySpeed.getValue().booleanValue()) break;
                Static.mc.player.field_70747_aH = this.speed.getValue().floatValue();
                if (Static.mc.gameSettings.keyBindJump.isKeyDown()) {
                    Static.mc.player.field_70181_x += (double)this.speed.getValue().floatValue();
                }
                if (!Static.mc.gameSettings.keyBindSneak.isKeyDown()) break;
                Static.mc.player.field_70181_x -= (double)this.speed.getValue().floatValue();
                break;
            }
            case ROOF: {
                Static.mc.player.connection.sendPacket(new CPacketPlayer.Position(Static.mc.player.field_70165_t, 10000.0, Static.mc.player.field_70161_v, Static.mc.player.field_70122_E));
                if (!this.disabler.getValue().booleanValue()) break;
                this.disable();
                break;
            }
            case NOVOID: {
                if (Static.mc.player.field_70145_X || !(Static.mc.player.field_70163_u <= (double)this.height.getValue().floatValue())) break;
                RayTraceResult trace = Static.mc.world.func_147447_a(Static.mc.player.func_174791_d(), new Vec3d(Static.mc.player.field_70165_t, 0.0, Static.mc.player.field_70161_v), false, false, false);
                if (trace != null && trace.typeOfHit == RayTraceResult.Type.BLOCK) {
                    return;
                }
                if (Phobos.moduleManager.isModuleEnabled(Phase.class) || Phobos.moduleManager.isModuleEnabled(Flight.class)) {
                    return;
                }
                Static.mc.player.func_70016_h(0.0, 0.0, 0.0);
                if (Static.mc.player.func_184187_bx() == null) break;
                Static.mc.player.func_184187_bx().setVelocity(0.0, 0.0, 0.0);
            }
        }
    }

    @Override
    public String getDisplayInfo() {
        if (this.mode.getValue() == Mode.ROOF) {
            return "Roof";
        }
        if (this.mode.getValue() == Mode.NOVOID) {
            return "NoVoid";
        }
        return null;
    }

    public static enum Mode {
        STATIC,
        ROOF,
        NOVOID;

    }
}
