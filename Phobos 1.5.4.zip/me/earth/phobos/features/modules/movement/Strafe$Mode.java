package me.earth.phobos.features.modules.movement;

public enum Strafe$Mode {
    NONE,
    NCP,
    BHOP;

}
