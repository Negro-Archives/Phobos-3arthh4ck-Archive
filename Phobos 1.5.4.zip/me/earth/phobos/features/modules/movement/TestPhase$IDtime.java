package me.earth.phobos.features.modules.movement;

import me.earth.phobos.util.Timer;
import net.minecraft.util.math.Vec3d;

public class TestPhase$IDtime {
    private final Vec3d pos;
    private final Timer timer;

    public TestPhase$IDtime(Vec3d pos, Timer timer) {
        this.pos = pos;
        this.timer = timer;
        this.timer.reset();
    }

    public Vec3d getPos() {
        return this.pos;
    }

    public Timer getTimer() {
        return this.timer;
    }
}
