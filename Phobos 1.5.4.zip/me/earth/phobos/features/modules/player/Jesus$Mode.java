package me.earth.phobos.features.modules.player;

public enum Jesus$Mode {
    TRAMPOLINE,
    BOUNCE,
    VANILLA,
    NORMAL;

}
