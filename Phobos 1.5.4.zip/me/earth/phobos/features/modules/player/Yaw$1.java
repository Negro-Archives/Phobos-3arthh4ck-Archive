package me.earth.phobos.features.modules.player;

import me.earth.phobos.features.modules.player.Yaw;

class Yaw$1 {
    static final int[] $SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction;

    static {
        $SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction = new int[Yaw.Direction.values().length];
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.NORTH.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.NE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.EAST.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.SE.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.SOUTH.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.SW.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.WEST.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Yaw$1.$SwitchMap$me$earth$phobos$features$modules$player$Yaw$Direction[Yaw.Direction.NW.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
