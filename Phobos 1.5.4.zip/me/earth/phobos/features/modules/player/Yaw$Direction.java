package me.earth.phobos.features.modules.player;

public enum Yaw$Direction {
    NORTH,
    NE,
    EAST,
    SE,
    SOUTH,
    SW,
    WEST,
    NW;

}
