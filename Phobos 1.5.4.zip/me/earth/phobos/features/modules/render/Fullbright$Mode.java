package me.earth.phobos.features.modules.render;

public enum Fullbright$Mode {
    GAMMA,
    POTION;

}
