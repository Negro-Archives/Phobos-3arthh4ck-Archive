package me.earth.phobos.features.modules.render;

public enum NoRender$Fog {
    NONE,
    AIR,
    NOFOG;

}
