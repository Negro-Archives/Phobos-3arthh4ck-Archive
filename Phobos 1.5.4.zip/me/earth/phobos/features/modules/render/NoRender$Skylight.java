package me.earth.phobos.features.modules.render;

public enum NoRender$Skylight {
    NONE,
    WORLD,
    ENTITY,
    ALL;

}
