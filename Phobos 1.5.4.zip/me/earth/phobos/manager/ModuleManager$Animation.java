package me.earth.phobos.manager;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.modules.client.HUD;
import me.earth.phobos.util.Util;

class ModuleManager$Animation
extends Thread {
    ScheduledExecutorService service;
    public Module module;
    public float offset;
    public float vOffset;

    public ModuleManager$Animation() {
        super("Animation");
        this.service = Executors.newSingleThreadScheduledExecutor();
    }

    @Override
    public void run() {
        for (Module module : ModuleManager.this.sortedModules) {
            String text = module.getDisplayName() + "\u00a77" + (module.getDisplayInfo() != null ? " [\u00a7f" + module.getDisplayInfo() + "\u00a77" + "]" : "");
            module.offset = (float)ModuleManager.this.renderer.getStringWidth(text) / HUD.getInstance().animationHorizontalTime.getValue().floatValue();
            module.vOffset = (float)ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue().floatValue();
            if (module.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                if (!(module.arrayListOffset > module.offset) || Util.mc.world == null) continue;
                module.arrayListOffset -= module.offset;
                module.sliding = true;
                continue;
            }
            if (!module.isDisabled() || HUD.getInstance().animationHorizontalTime.getValue() == 1) continue;
            if (module.arrayListOffset < (float)ModuleManager.this.renderer.getStringWidth(text) && Util.mc.world != null) {
                module.arrayListOffset += module.offset;
                module.sliding = true;
                continue;
            }
            module.sliding = false;
        }
    }

    @Override
    public void start() {
        System.out.println("Starting animation thread.");
        this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
    }
}
