package org.json;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONPointer;

public class JSONPointer$Builder {
    private final List<String> refTokens = new ArrayList<String>();

    public JSONPointer build() {
        return new JSONPointer(this.refTokens);
    }

    public JSONPointer$Builder append(String token) {
        if (token == null) {
            throw new NullPointerException("token cannot be null");
        }
        this.refTokens.add(token);
        return this;
    }

    public JSONPointer$Builder append(int arrayIndex) {
        this.refTokens.add(String.valueOf(arrayIndex));
        return this;
    }
}
