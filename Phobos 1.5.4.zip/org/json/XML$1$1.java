// ERROR: Unable to apply inner class name fixup
package org.json;

import java.util.Iterator;

class XML.1
implements Iterator<Integer> {
    private int nextIndex = 0;
    private int length;

    XML.1() {
        this.length = val$string.length();
    }

    @Override
    public boolean hasNext() {
        return this.nextIndex < this.length;
    }

    @Override
    public Integer next() {
        int result = val$string.codePointAt(this.nextIndex);
        this.nextIndex += Character.charCount(result);
        return result;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
