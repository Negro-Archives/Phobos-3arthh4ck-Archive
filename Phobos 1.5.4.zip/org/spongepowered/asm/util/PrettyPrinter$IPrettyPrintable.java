package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter;

public interface PrettyPrinter$IPrettyPrintable {
    public void print(PrettyPrinter var1);
}
