package org.spongepowered.tools.obfuscation.interfaces;

public enum IMixinValidator$ValidationPass {
    EARLY,
    LATE,
    FINAL;

}
