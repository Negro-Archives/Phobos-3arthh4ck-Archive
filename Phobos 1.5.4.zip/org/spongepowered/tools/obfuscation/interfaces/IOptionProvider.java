package org.spongepowered.tools.obfuscation.interfaces;

public interface IOptionProvider {
    public String getOption(String var1);
}
