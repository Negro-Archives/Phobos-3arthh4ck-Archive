package club.minnced.discord.rpc;

import com.sun.jna.Callback;

public interface DiscordEventHandlers$OnGameUpdate
extends Callback {
    public void accept(String var1);
}
