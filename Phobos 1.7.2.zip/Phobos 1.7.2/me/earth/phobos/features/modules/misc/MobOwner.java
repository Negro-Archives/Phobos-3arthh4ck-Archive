package me.earth.phobos.features.modules.misc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.util.PlayerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;

public class MobOwner
extends Module {
    private final Map<Entity, String> owners = new HashMap<Entity, String>();
    private final Map<Entity, UUID> toLookUp = new ConcurrentHashMap<Entity, UUID>();
    private final List<Entity> lookedUp = new ArrayList<Entity>();

    public MobOwner() {
        super("MobOwner", "Shows you who owns mobs.", Module.Category.MISC, false, false, false);
    }

    @Override
    public void onUpdate() {
        if (MobOwner.fullNullCheck()) {
            return;
        }
        if (PlayerUtil.timer.passedS(5.0)) {
            for (Map.Entry<Entity, UUID> entry : this.toLookUp.entrySet()) {
                Entity entity = entry.getKey();
                UUID uuid = entry.getValue();
                if (uuid != null) {
                    EntityPlayer owner = MobOwner.mc.world.func_152378_a(uuid);
                    if (owner != null) {
                        this.owners.put(entity, owner.getName());
                        this.lookedUp.add(entity);
                        continue;
                    }
                    try {
                        String name = PlayerUtil.getNameFromUUID(uuid);
                        if (name != null) {
                            this.owners.put(entity, name);
                            this.lookedUp.add(entity);
                        }
                    }
                    catch (Exception e) {
                        this.lookedUp.add(entity);
                        this.toLookUp.remove(entry);
                    }
                    PlayerUtil.timer.reset();
                    break;
                }
                this.lookedUp.add(entity);
                this.toLookUp.remove(entry);
            }
        }
        for (Entity entity : MobOwner.mc.world.func_72910_y()) {
            Object tameableEntity;
            if (entity.getAlwaysRenderNameTag()) continue;
            if (entity instanceof EntityTameable) {
                tameableEntity = (EntityTameable)((Object)entity);
                if (!tameableEntity.isTamed() || tameableEntity.getOwnerId() == null) continue;
                if (this.owners.get(tameableEntity) != null) {
                    ((EntityTameable)tameableEntity).func_174805_g(true);
                    ((EntityTameable)tameableEntity).func_96094_a(this.owners.get(tameableEntity));
                    continue;
                }
                if (this.lookedUp.contains(entity)) continue;
                this.toLookUp.put((Entity)tameableEntity, tameableEntity.getOwnerId());
                continue;
            }
            if (!(entity instanceof AbstractHorse) || !(tameableEntity = (AbstractHorse)((Object)entity)).isTame() || tameableEntity.getOwnerUniqueId() == null) continue;
            if (this.owners.get(tameableEntity) != null) {
                ((AbstractHorse)tameableEntity).func_174805_g(true);
                ((AbstractHorse)tameableEntity).func_96094_a(this.owners.get(tameableEntity));
                continue;
            }
            if (this.lookedUp.contains(entity)) continue;
            this.toLookUp.put((Entity)tameableEntity, tameableEntity.getOwnerUniqueId());
        }
    }

    @Override
    public void onDisable() {
        for (Entity entity : MobOwner.mc.world.field_72996_f) {
            if (!(entity instanceof EntityTameable) && !(entity instanceof AbstractHorse)) continue;
            try {
                entity.setAlwaysRenderNameTag(false);
            }
            catch (Exception exception) {}
        }
    }
}
