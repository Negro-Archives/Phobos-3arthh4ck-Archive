package me.earth.phobos.features.modules.player;

import me.earth.phobos.event.events.PacketEvent;
import me.earth.phobos.event.events.PushEvent;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.MathUtil;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketSetPassengers;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Freecam
extends Module {
    public Setting<Double> speed = this.register(new Setting<Double>("Speed", 0.5, 0.1, 5.0));
    public Setting<Boolean> view = this.register(new Setting<Boolean>("3D", false));
    public Setting<Boolean> packet = this.register(new Setting<Boolean>("Packet", true));
    public Setting<Boolean> disable = this.register(new Setting<Boolean>("Logout/Off", true));
    private static Freecam INSTANCE = new Freecam();
    private AxisAlignedBB oldBoundingBox;
    private EntityOtherPlayerMP entity;
    private Vec3d position;
    private Entity riding;
    private float yaw;
    private float pitch;

    public Freecam() {
        super("Freecam", "Look around freely.", Module.Category.PLAYER, true, false, false);
        this.setInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public static Freecam getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Freecam();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        if (!Freecam.fullNullCheck()) {
            this.oldBoundingBox = Freecam.mc.player.func_174813_aQ();
            Freecam.mc.player.func_174826_a(new AxisAlignedBB(Freecam.mc.player.field_70165_t, Freecam.mc.player.field_70163_u, Freecam.mc.player.field_70161_v, Freecam.mc.player.field_70165_t, Freecam.mc.player.field_70163_u, Freecam.mc.player.field_70161_v));
            if (Freecam.mc.player.func_184187_bx() != null) {
                this.riding = Freecam.mc.player.func_184187_bx();
                Freecam.mc.player.dismountRidingEntity();
            }
            this.entity = new EntityOtherPlayerMP(Freecam.mc.world, Freecam.mc.session.getProfile());
            this.entity.func_82149_j(Freecam.mc.player);
            this.entity.field_70177_z = Freecam.mc.player.field_70177_z;
            this.entity.field_70759_as = Freecam.mc.player.field_70759_as;
            this.entity.field_71071_by.copyInventory(Freecam.mc.player.field_71071_by);
            Freecam.mc.world.addEntityToWorld(69420, this.entity);
            this.position = Freecam.mc.player.func_174791_d();
            this.yaw = Freecam.mc.player.field_70177_z;
            this.pitch = Freecam.mc.player.field_70125_A;
            Freecam.mc.player.field_70145_X = true;
        }
    }

    @Override
    public void onDisable() {
        if (!Freecam.fullNullCheck()) {
            Freecam.mc.player.func_174826_a(this.oldBoundingBox);
            if (this.riding != null) {
                Freecam.mc.player.startRiding(this.riding, true);
            }
            if (this.entity != null) {
                Freecam.mc.world.removeEntity(this.entity);
            }
            if (this.position != null) {
                Freecam.mc.player.func_70107_b(this.position.x, this.position.y, this.position.z);
            }
            Freecam.mc.player.field_70177_z = this.yaw;
            Freecam.mc.player.field_70125_A = this.pitch;
            Freecam.mc.player.field_70145_X = false;
        }
    }

    @Override
    public void onUpdate() {
        Freecam.mc.player.field_70145_X = true;
        Freecam.mc.player.func_70016_h(0.0, 0.0, 0.0);
        Freecam.mc.player.field_70747_aH = this.speed.getValue().floatValue();
        double[] dir = MathUtil.directionSpeed(this.speed.getValue());
        if (Freecam.mc.player.movementInput.moveStrafe != 0.0f || Freecam.mc.player.movementInput.moveForward != 0.0f) {
            Freecam.mc.player.field_70159_w = dir[0];
            Freecam.mc.player.field_70179_y = dir[1];
        } else {
            Freecam.mc.player.field_70159_w = 0.0;
            Freecam.mc.player.field_70179_y = 0.0;
        }
        Freecam.mc.player.setSprinting(false);
        if (this.view.getValue().booleanValue() && !Freecam.mc.gameSettings.keyBindSneak.isKeyDown() && !Freecam.mc.gameSettings.keyBindJump.isKeyDown()) {
            Freecam.mc.player.field_70181_x = this.speed.getValue() * -MathUtil.degToRad(Freecam.mc.player.field_70125_A) * (double)Freecam.mc.player.movementInput.moveForward;
        }
        if (Freecam.mc.gameSettings.keyBindJump.isKeyDown()) {
            Freecam.mc.player.field_70181_x += this.speed.getValue().doubleValue();
        }
        if (Freecam.mc.gameSettings.keyBindSneak.isKeyDown()) {
            Freecam.mc.player.field_70181_x -= this.speed.getValue().doubleValue();
        }
    }

    @Override
    public void onLogout() {
        if (this.disable.getValue().booleanValue()) {
            this.disable();
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (this.packet.getValue().booleanValue()) {
            if (event.getPacket() instanceof CPacketPlayer) {
                event.setCanceled(true);
            }
        } else if (!(event.getPacket() instanceof CPacketUseEntity || event.getPacket() instanceof CPacketPlayerTryUseItem || event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock || event.getPacket() instanceof CPacketPlayer || event.getPacket() instanceof CPacketVehicleMove || event.getPacket() instanceof CPacketChatMessage || event.getPacket() instanceof CPacketKeepAlive)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        Object packet;
        Entity riding;
        if (event.getPacket() instanceof SPacketSetPassengers && (riding = Freecam.mc.world.getEntityByID((packet = (SPacketSetPassengers)event.getPacket()).getEntityId())) != null && riding == this.riding) {
            this.riding = null;
        }
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            packet = (SPacketPlayerPosLook)event.getPacket();
            if (this.packet.getValue().booleanValue()) {
                if (this.entity != null) {
                    this.entity.func_70080_a(packet.getX(), packet.getY(), packet.getZ(), packet.getYaw(), packet.getPitch());
                }
                this.position = new Vec3d(packet.getX(), packet.getY(), packet.getZ());
                Freecam.mc.player.connection.sendPacket(new CPacketConfirmTeleport(packet.getTeleportId()));
                event.setCanceled(true);
            } else {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onPush(PushEvent event) {
        if (event.getStage() == 1) {
            event.setCanceled(true);
        }
    }
}
