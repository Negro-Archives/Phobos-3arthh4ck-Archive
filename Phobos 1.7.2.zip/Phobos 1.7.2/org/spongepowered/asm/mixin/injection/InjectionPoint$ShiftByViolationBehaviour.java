package org.spongepowered.asm.mixin.injection;

enum InjectionPoint$ShiftByViolationBehaviour {
    IGNORE,
    WARN,
    ERROR;

}
