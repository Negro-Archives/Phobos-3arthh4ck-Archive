package org.spongepowered.asm.mixin.injection.invoke.util;

enum InsnFinder$AnalyzerState {
    SEARCH,
    ANALYSE,
    COMPLETE;

}
